/**
 * Created on 23/09/2015.
 */
Ext.define('APP.store.AccountTree', {
    extend: 'Ext.data.TreeStore',
    model: 'APP.model.AccountTree',
    folderSort: true
});