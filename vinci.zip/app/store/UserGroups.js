// JavaScript Document
Ext.define('APP.store.UserGroups', {
    extend: 'Ext.data.Store',
    model: 'APP.model.UserGroup'
});