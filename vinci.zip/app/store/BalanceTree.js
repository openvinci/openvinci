/**
 * Created on 23/09/2015.
 */
Ext.define('APP.store.BalanceTree', {
    extend: 'Ext.data.TreeStore',
    model: 'APP.model.BalanceTree',
    folderSort: true
});