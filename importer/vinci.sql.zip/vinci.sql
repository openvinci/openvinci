-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2015 at 12:25 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vinci`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consolidados`
--

CREATE TABLE IF NOT EXISTS `tbl_consolidados` (
  `contabilidad` int(11) NOT NULL,
  `origen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contabilidad`
--

CREATE TABLE IF NOT EXISTS `tbl_contabilidad` (
`id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tipo_cierre` varchar(10) NOT NULL,
  `cuenta_cierre` int(11) DEFAULT NULL,
  `tipo_numeracion` varchar(10) NOT NULL,
  `prefijo_partida` varchar(10) DEFAULT NULL,
  `numero_partida` int(11) DEFAULT NULL,
  `lugares_partida` int(11) DEFAULT NULL,
  `consolidada` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cuenta`
--

CREATE TABLE IF NOT EXISTS `tbl_cuenta` (
  `id` int(11) NOT NULL,
  `nombre` tinytext NOT NULL,
  `padre` int(11) DEFAULT NULL,
  `detalle` tinyint(1) DEFAULT NULL,
  `grupo` int(11) NOT NULL,
  `nivel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_grupo`
--

CREATE TABLE IF NOT EXISTS `tbl_grupo` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `debe` tinyint(1) DEFAULT NULL COMMENT 'comportamiento de la cuenta:\ndebe = 1, haber = 0',
  `editable` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_grupo`
--

INSERT INTO `tbl_grupo` (`id`, `nombre`, `debe`, `editable`) VALUES
(1, 'Activos', 1, 0),
(2, 'Capital', 0, 0),
(3, 'Gastos', 1, 0),
(4, 'Ingresos', 0, 0),
(5, 'Otros CR', 1, 0),
(6, 'Otros DB', 0, 0),
(7, 'Pasivos', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_periodo`
--

CREATE TABLE IF NOT EXISTS `tbl_periodo` (
`id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  `ejercicio` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
`id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `email` tinytext,
  `pass` tinytext,
  `type` int(11) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `email`, `pass`, `type`, `active`) VALUES
(1, 'Administrador', NULL, NULL, 0, 1),
(2, 'Administrador', 'dont@mail.me', 'root', 1, 1),
(3, 'Supervisor', NULL, NULL, 0, 1),
(4, 'Gerente', NULL, NULL, 0, 1),
(5, 'Operador Avanzado', NULL, NULL, 0, 1),
(6, 'Operador Medio', NULL, NULL, 0, 1),
(7, 'Operador Basico', NULL, NULL, 0, 1),
(8, 'Operador Banco', NULL, NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_contab`
--

CREATE TABLE IF NOT EXISTS `tbl_user_contab` (
  `user` int(11) NOT NULL,
  `contabilidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_permits`
--

CREATE TABLE IF NOT EXISTS `tbl_user_permits` (
  `user` int(11) NOT NULL,
  `permit` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_permits`
--

INSERT INTO `tbl_user_permits` (`user`, `permit`) VALUES
(1, '1'),
(1, '2'),
(2, '1'),
(2, '10'),
(2, '103'),
(2, '104'),
(2, '11'),
(2, '13'),
(2, '14'),
(2, '2'),
(2, '3'),
(2, '4'),
(2, '5'),
(2, '8'),
(2, '9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_consolidados`
--
ALTER TABLE `tbl_consolidados`
 ADD PRIMARY KEY (`contabilidad`), ADD KEY `fk_tbl_origenes_tbl_contabilidad2_idx` (`origen`);

--
-- Indexes for table `tbl_contabilidad`
--
ALTER TABLE `tbl_contabilidad`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_tbl_contabilidad_tbl_cuenta1_idx` (`cuenta_cierre`);

--
-- Indexes for table `tbl_cuenta`
--
ALTER TABLE `tbl_cuenta`
 ADD PRIMARY KEY (`id`,`grupo`), ADD UNIQUE KEY `uk_tbl_cuenta` (`id`), ADD KEY `fk_tbl_cuenta_tbl_grupo_balance1_idx` (`grupo`);

--
-- Indexes for table `tbl_grupo`
--
ALTER TABLE `tbl_grupo`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_periodo`
--
ALTER TABLE `tbl_periodo`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_contab`
--
ALTER TABLE `tbl_user_contab`
 ADD PRIMARY KEY (`user`,`contabilidad`), ADD KEY `fk_tbl_user_contab_tbl_contabilidad1_idx` (`contabilidad`);

--
-- Indexes for table `tbl_user_permits`
--
ALTER TABLE `tbl_user_permits`
 ADD PRIMARY KEY (`user`,`permit`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_contabilidad`
--
ALTER TABLE `tbl_contabilidad`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_grupo`
--
ALTER TABLE `tbl_grupo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_periodo`
--
ALTER TABLE `tbl_periodo`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_consolidados`
--
ALTER TABLE `tbl_consolidados`
ADD CONSTRAINT `fk_tbl_origenes_tbl_contabilidad1` FOREIGN KEY (`contabilidad`) REFERENCES `tbl_contabilidad` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `fk_tbl_origenes_tbl_contabilidad2` FOREIGN KEY (`origen`) REFERENCES `tbl_contabilidad` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_contabilidad`
--
ALTER TABLE `tbl_contabilidad`
ADD CONSTRAINT `fk_tbl_contabilidad_tbl_cuenta1` FOREIGN KEY (`cuenta_cierre`) REFERENCES `tbl_cuenta` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_cuenta`
--
ALTER TABLE `tbl_cuenta`
ADD CONSTRAINT `fk_tbl_cuenta_tbl_grupo_balance1` FOREIGN KEY (`grupo`) REFERENCES `tbl_grupo` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `tbl_user_contab`
--
ALTER TABLE `tbl_user_contab`
ADD CONSTRAINT `fk_tbl_user_contab_tbl_contabilidad1` FOREIGN KEY (`contabilidad`) REFERENCES `tbl_contabilidad` (`id`) ON UPDATE CASCADE,
ADD CONSTRAINT `fk_tbl_user_contab_tbl_users1` FOREIGN KEY (`user`) REFERENCES `tbl_users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_user_permits`
--
ALTER TABLE `tbl_user_permits`
ADD CONSTRAINT `fk_tbl_user_permits_tbl_users` FOREIGN KEY (`user`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
