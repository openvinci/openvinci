/**
 * Created on 19/10/2015.
 */
Ext.define('APP.view.folder.Balance', {
    extend: 'Ext.window.Window',
    alias: 'widget.balanceCatalog',
    glyph:112,
    title: 'Balances',
    layout: 'fit',
    autoShow: true,
    modal:true,
    resizable:false,
    width:1000,
    constrainHeader:true,

    initComponent: function() {
        Ext.applyIf(this, {
            items:[{
                xtype: 'treepanel',
                height: 400,
                useArrows: true,
                rootVisible: false,
                autoScroll: true,
                store: 'BalanceTree',
                tbar:['->', {
                    xtype: 'combobox',
                    store: 'Balance',
                    name: 'balance',
                    allowBlank: false,
                    fieldLabel: 'Periodo',
                    labelWidth:60,
                    editable: false,
                    valueField:'id',
                    displayField:'periodName',
                    listeners:{change:this.filterTree}
                }],
                columns: [{
                    text: 'No. Cuenta',
                    dataIndex: 'id',
                    width: 100
                }, {
                    xtype: 'treecolumn',
                    text: 'Nombre',
                    flex: 1,
                    dataIndex: 'text'
                },{
                    text:'Balance Inicial',
                    columns: [{
                        text: 'Debe',
                        dataIndex: 'ini_debe',
                        xtype: 'numbercolumn',
                        align:'right'
                    },{
                        text: 'Haber',
                        dataIndex: 'ini_haber',
                        xtype: 'numbercolumn',
                        align:'right'
                    }]
                },{
                    text:'Balance del Periodo',
                    columns: [{
                        text: 'Debe',
                        dataIndex: 'per_debe',
                        xtype: 'numbercolumn',
                        align:'right'
                    },{
                        text: 'Haber',
                        dataIndex: 'per_haber',
                        xtype: 'numbercolumn',
                        align:'right'
                    }]
                },{
                    text:'Balance Final',
                    columns: [{
                        text: 'Debe',
                        dataIndex: 'fin_debe',
                        xtype: 'numbercolumn',
                        align:'right'
                    },{
                        text: 'Haber',
                        dataIndex: 'fin_haber',
                        xtype: 'numbercolumn',
                        align:'right'
                    }]
                }]
            }]
        });
        this.callParent(arguments);
    },
    filterTree:function(el,v){
        var bTree = Ext.getStore('BalanceTree');
        bTree.load({
            params:{balance:v}
        });
    }
});