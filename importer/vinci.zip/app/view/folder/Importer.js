/**
 * Created on 03/10/2015.
 */
Ext.define('APP.view.folder.Importer', {
    extend: 'Ext.window.Window',
    alias: 'widget.importerMaster',
    glyph:77,
    title: 'Importar Carpeta de Vinci 4.5',
    layout: 'fit',
    autoShow: true,
    modal:true,
    resizable:false,
    width:500,
    filename:'', //name of the imported zip file
    folder:0, //folder id of the imported zip
    constrainHeader:true,

    initComponent: function() {
        Ext.applyIf(this, {
           items:[{
               xtype:'form',
               padding: 5,
               border:false,
               items:[{
                   xtype: 'filefield',
                   name: 'workfolder',
                   fieldLabel: 'Carpeta',
                   labelWidth:120,
                   msgTarget: 'side',
                   allowBlank: false,
                   anchor: '100%',
                   listeners:{
                       change:this.submitFrm
                   }
               }, {
                   itemId: 'status',
                   xtype: 'progressbar',
                   text: 'Esperando...'
               },{
                   padding:5,
                   border:false,
                   html:'<h3>reglas y metodo</h3><p>TO DO</p>'
               }]
           }]
        });
        this.callParent(arguments);
    },
    submitFrm:function(el){
        el.up('form').submit({
            clientValidation: true,
            scope:this,
            url:'importer/upload.php',
            success: function(form, action) {
                //action.result.msg
                this.up('window').filename = action.result.msg;
                //console.log(action.result.msg, this);
                this.up('window').checkAccounts();
            },
            failure: function(form, action) {
                switch (action.failureType) {
                    case Ext.form.action.Action.CLIENT_INVALID:
                        Ext.Msg.alert('Error', 'Los campos del formulario no pueden ser enviados con errores');
                        break;
                    case Ext.form.action.Action.CONNECT_FAILURE:
                        Ext.Msg.alert('Error', 'Error de comunicacion Ajax');
                        break;
                    case Ext.form.action.Action.SERVER_INVALID:
                        Ext.Msg.alert('Error', action.result.msg);
                }
            }
        });
    },
    checkAccounts:function(){
        this.down('#status').updateProgress(.1,'verificando cuentas');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/accounts.php',
            params:{id:this.filename},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    Ext.getStore('Groups').reload();
                    Ext.getStore('Accounts').reload();
                    this.checkPeriods();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    checkPeriods:function(){
        this.down('#status').updateProgress(.2,'verificando periodos');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/periods.php',
            params:{id:this.filename},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    Ext.getStore('Periods').reload();
                    this.checkEntryTypes();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    checkEntryTypes:function(){
        this.down('#status').updateProgress(.3,'verificando tipos de partidas');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/entryTypes.php',
            params:{id:this.filename},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    Ext.getStore('EntryTypes').reload();
                    this.importFolder();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    importFolder:function(){
        this.down('#status').updateProgress(.4,'creando carpeta');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/folder.php',
            params:{id:this.filename},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    Ext.getStore('Folders').reload();
                    this.folder = obj.msg;
                    this.balance();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    balance:function(){
        this.down('#status').updateProgress(.5,'creando balances');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/balance.php',
            params:{id:this.filename, folder:this.folder},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    Ext.getStore('Balance').reload();
                    this.books();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    books:function(){
        this.down('#status').updateProgress(.6,'creando libros');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/books.php',
            params:{id:this.filename, folder:this.folder},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    this.cleanUp();
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    },
    cleanUp:function(){
        this.down('#status').updateProgress(.9,'borrando temporales');
        Ext.Ajax.request({
            scope:this,
            url: 'importer/cleanup.php',
            params:{id:this.filename},
            success: function(response, opts) {
                var obj = Ext.decode(response.responseText);
                if(obj.success){
                    this.down('#status').updateProgress(0,obj.msg);
                }else this.down('#status').updateText(obj.msg);
            },
            failure: function(response, opts) {
                this.down('#status').updateText('server-side failure with status code ' + response.status);
            }
        });
    }
});