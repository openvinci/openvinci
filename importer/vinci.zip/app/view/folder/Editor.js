/**
 * Created on 19/10/2015.
 */
Ext.define('APP.view.folder.Editor', {
    extend: 'Ext.window.Window',
    alias: 'widget.folderEditor',
    glyph:100,
    title: 'Contabilidad',
    layout: 'fit',
    autoShow: true,
    modal:true,
    resizable:false,
    width:600,
    constrainHeader:true,

    initComponent: function() {
        //local close account array
        var Accs=[];
        Ext.getStore('Accounts').each(function(r){
            var group = Ext.getStore('Groups').findRecord('id', r.get('grupo'),0,false,false,true);
            if(group.get('id') == 2 && r.get('detalle') == true){
                Accs.push([r.get('id'),r.get('id')+' - '+ r.get('nombre')]);
            }
        },this);

        //populate origins
        var chkOrgs=[];
        Ext.getStore('Folders').each(function(r){
            chkOrgs.push({
                 boxLabel: r.get('nombre'), name: 'origins', inputValue: r.get('id')
            });
        },this);

        //populate users
        var chkUsrs=[];
        Ext.getStore('UserList').each(function(r){
            chkUsrs.push({
                boxLabel: r.get('nombre'), name: 'users', inputValue: r.get('id')
            });
        },this);

        Ext.applyIf(this, {
            items:[{
                xtype:'form',
                border:false,
                layout:'column',
                items:[{
                    columnWidth: 0.50,
                    border:false,
                    padding:5,
                    layout:'form',
                    items:[{
                        xtype: 'hidden',
                        name: 'id'
                    }, {
                        xtype: 'textfield',
                        fieldLabel: 'Nombre',
                        name: 'nombre',
                        labelWidth:60
                    }, {
                        xtype:'fieldset',
                        title:'Cierre Anual',
                        defaults: {anchor: '100%', labelWidth:60},
                        items:[{
                            xtype: 'combobox',
                            store: ['total', 'resultados'],
                            name: 'tipo_cierre',
                            anchor:'100%',
                            allowBlank: false,
                            fieldLabel: 'Tipo',
                            editable: false,
                            value:'total'
                        },{
                            xtype: 'combobox',
                            store: Accs,
                            matchFieldWidth:false,
                            name: 'cuenta_cierre',
                            anchor:'100%',
                            allowBlank:false,
                            fieldLabel:'Cuenta',
                            editable:false
                        }]
                    }, {
                        xtype:'fieldset',
                        title:'Numeración de partidas de diario',
                        defaults: {anchor: '100%', labelWidth:60},
                        items:[{
                            xtype: 'combobox',
                            store: ['global', 'por libro'],
                            name: 'tipo_numeracion',
                            anchor: '100%',
                            allowBlank: false,
                            fieldLabel: 'Tipo',
                            editable: false,
                            value:'global',
                            listeners:{change:this.setNumberingType}
                        },{
                            xtype: 'textfield',
                            fieldLabel: 'Prefijo',
                            name: 'prefijo_partida',
                            maxLength:10,
                            listeners:{'change':this.updateSample}
                        }, {
                            xtype: 'numberfield',
                            fieldLabel: 'Lugares',
                            name: 'lugares_partida',
                            allowExponential: false,
                            allowDecimals: false,
                            listeners:{'change':this.updateSample}
                        }, {
                            xtype: 'numberfield',
                            fieldLabel: 'Numero',
                            name: 'numero_partida',
                            allowExponential: false,
                            allowDecimals: false,
                            listeners:{'change':this.updateSample}
                        }, {
                            xtype: 'displayfield',
                            name: 'sample',
                            fieldLabel: 'muestra'
                        }, {
                            xtype:'hidden',
                            name:'consolidada'
                        }]
                    }]
                }, {
                    columnWidth: 0.50,
                    height: 320,
                    layout: 'accordion',
                    itemId: 'dependencies',
                    items: [{
                        title: 'consolidacion de datos',
                        autoScroll:true,
                        items:[{
                            xtype:'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId:'originList',
                            items:chkOrgs
                        }]
                    }, {
                        title: 'usuarios',
                        autoScroll:true,
                        items:[{
                            xtype:'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId:'userList',
                            items:chkUsrs
                        }]
                    }, {
                        title: 'Presupuestos'
                    }]
                }],
                buttons:[{
                    xtype:'button',
                    text:'Cancelar',
                    itemId:'resetFrm',
                    scale:'medium',
                    handler:function(el){el.up('window').close()}
                },'->',{
                    xtype:'button',
                    itemId:'saveFrm',
                    action: 'save',
                    scale:'medium',
                    text:'Guardar'
                }]
            }]
        });
        this.callParent(arguments);
    },
    updateSample:function(el){
        var frm = el.up('form'),
        values = frm.getValues(),
        sample =APP.consecutive(values.prefijo_partida, values.lugares_partida, values.numero_partida);
        frm.down('[name=sample]').setValue(sample);
    },
    OriginName:function(v){
        var r = Ext.getStore('Folders').findRecord('id',v,0,false,false,true);
        return r.get('nombre');
    },
    setNumberingType:function(el,v){
        var frm=el.up('form');
        if(v == 'global'){
            frm.down('[name=prefijo_partida]').enable();
            frm.down('[name=numero_partida]').enable();
            frm.down('[name=lugares_partida]').enable();
        }else{
            frm.down('[name=prefijo_partida]').disable();
            frm.down('[name=numero_partida]').disable();
            frm.down('[name=lugares_partida]').disable();
        }
    }
});