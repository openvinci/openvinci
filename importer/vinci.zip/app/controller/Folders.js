/**
 * Created on 19/10/2015.
 */
Ext.define('APP.controller.Folders', {
    extend: 'Ext.app.Controller',
    models: ['Folder', 'BalanceTree', 'Book', 'EntryType'],
    stores: ['Folders', 'BalanceTree', 'Books', 'EntryTypes'],
    views: [
        'folder.Importer', 'folder.Catalog', 'folder.Editor', 'folder.Balance', 'folder.DiaryButton',
        'book.Catalog', 'book.Editor'
    ],
    init: function () {
        this.control({
            '#navToolBar': {
                render: this.loadInterface
            },
            '#navToolBar [name=workfolder]':{
                change: this.changefilters
            },
            'folderCatalog #addItm':{
                click:this.addFolder
            },
            'folderEditor #saveFrm':{
                click:this.EditorSave
            },
            'bookCatalog #addItm':{
                click:this.addBook
            },
            'bookEditor #saveFrm':{
                click:this.SaveBook
            }
        });

        //generator function for consecutives
        APP.consecutive=function(prefix, places, value){
            var s = Ext.String.leftPad(value, places, '0');
            return prefix+s;
        }
    },

    loadInterface: function (el) {
        Ext.getStore('Folders').load();

        var admBttn=Ext.ComponentQuery.query('adminbutton')[0];
        var admMnu=admBttn.menu;

        if(APP.acl(3))admMnu.add({
            text:'Catálogo de Contabilidades',
            glyph:100,
            handler:function(){
                var win = Ext.widget('folderCatalog');
            }
        });

        var pBtn = Ext.ComponentQuery.query('periodbutton')[0];
        var prdmnu = pBtn.menu;

        if(APP.acl(37))prdmnu.add({
            text:'Balances',
            glyph:112,
            handler:function(){
                var win = Ext.widget('balanceCatalog');
                if(Ext.getStore('Balance').count()){
                    if(Ext.getStore('Balance').count()){
                        win.down('[name=balance]').select(Ext.getStore('Balance').first());
                    }else{
                        Ext.getStore('BalanceTree').removeAll();
                    }
                }
            }
        });

        var dryBtn = el.insert(1,{xtype:'diarybutton'});
        var drymnu = dryBtn.menu;

        if(APP.acl(21))drymnu.add({
            glyph:47,
            text:'Libros de diario',
            handler:function(el){
                var acc=Ext.ComponentQuery.query('#navToolBar [name=workfolder]')[0].getValue();
                if(acc){
                    var win = Ext.widget('bookCatalog');
                }else Ext.Msg.alert('Error', 'debe existir al menos una contabilidad definida');
            }
        });

        if(APP.acl(22))drymnu.add({
            glyph:47,
            text:'Tipos de Partidas',
            params: {title:'Tipos de Partidas', store:'EntryTypes',
                columns: [{
                    text: 'Nombre', dataIndex: 'nombre', flex: 1, sortable: true,
                    editor: {xtype: 'textfield', allowBlank: false}
                },{
                    text: 'Descripción', dataIndex: 'descrip', flex: 2, sortable: true,
                    editor: {xtype: 'textfield'}
                }],
                acl:{ create:22, update:22, destroy:22}
            },
            handler: this.getController('Masters').setGenericEditView
        });

        var accBttn=Ext.ComponentQuery.query('accountbutton')[0];
        var accMnu=accBttn.menu;
    },

    changefilters:function(el, v){
        var balance = Ext.getStore('Balance');
        balance.clearFilter(true);
        balance.filter('contabilidad',v);

        var books = Ext.getStore('Books');
        books.clearFilter(true);
        books.filter('contabilidad',v);

        //TODO reload stores on folder change
    },

    addFolder:function(el){
        var editor = Ext.widget('folderEditor');
        editor.down('#dependencies').disable();
    },

    EditorSave:function(el){
        var frm = el.up('form').getForm(),
            store = Ext.getStore('Folders'),
            values = frm.getValues();

        if(!values.users)values.users=[]; else
        if(Ext.isNumeric(values.users))values.users=[values.users];
        if(!values.origins)values.origins=[]; else
        if(Ext.isNumeric(values.origins))values.origins=[values.origins];

        if(values.id){
            //update record on store
            var rec = frm.getRecord();
            rec.set(values);
        }else{
            //add record to store
            store.add(values);
        }
        el.up('window').close();
        store.sync({
            scope:this,
            callback:function(){
                store.reload();
                Ext.getStore('Folders').reload();
            }
        });
    },

    addBook:function(el){
        var editor = Ext.widget('bookEditor');
        editor.down('[name=prefijo_partida]').setValue('P');
    },

    SaveBook:function(el){
        var frm = el.up('form').getForm(),
            store = Ext.getStore('Books'),
            values = frm.getValues();

        if(values.id){
            //update record on store
            var rec = frm.getRecord();
            rec.set(values);
        }else{
            //add record to store
            store.add(values);
        }
        el.up('window').close();
        store.sync({
            scope:this,
            callback:function(){
                store.reload();
                Ext.getStore('Books').reload();
            }
        });
    }
});