// JavaScript Document
Ext.define('APP.store.Groups', {
    extend: 'Ext.data.Store',
    model: 'APP.model.Group',
    autoLoad:true
});