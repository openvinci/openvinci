<?php require('mail.php');
date_default_timezone_set('America/Guatemala');

$account="{mail.openvinci.org:143/novalidate-cert}";
$user='builder@openvinci.org';
$pass='Immanis1979';

/*
$account="{localhost:143}";
$user='user@test.me';
$pass='test';
*/

if($mbox = imap_open($account, $user, $pass)){

    $list = imap_getmailboxes($mbox, "{imap.example.org}", "*");
    if (is_array($list))$json['mailboxes']=$list;

    if($mx=imap_num_msg($mbox)){
        //kill messages older than today
        //$date = date ( "d M Y" );
        $date = date ( "d M Y", strtotime('-3 days'));
        $uids = imap_search ( $mbox, "BEFORE \"$date\"", SE_UID );
        if($uids)foreach($uids as $oldMsg)imap_delete($mbox, $oldMsg, FT_UID);
        imap_expunge($mbox);


        $i=1;
        $header=imap_headerinfo($mbox,$i);
        $json['header']=$header;
        $referer=$header->fromaddress;
        $struc=imap_fetchstructure($mbox,$i);
        //seek for attachtments
        if($struc->parts){
            foreach ($struc->parts as $ind => $p){
                $json['partStruct'][]=$p;
                $part=imap_fetchbody($mbox,$i, $ind+1);
                if($p->encoding==4) $part = quoted_printable_decode($part);
                elseif ($p->encoding==3) $part = base64_decode($part);
                $json['part'][]=strlen($part);
                if(strtoupper($p->subtype)=="OCTET-STREAM"){
                    //this is a compressed zip
                    $g=tempnam('./','gz');
                    file_put_contents($g,$part);
                    $zip = new ZipArchive;
                    $res = $zip->open($g);
                    if ($res === TRUE) {
                        $zip->extractTo('../../');
                        $zip->close();
                    } else {
                        echo 'failed, code:' . $res;
                    }
                    unlink($g);
                }
            }
        }

        //read main content
        $body=explode(PHP_EOL, imap_qprint(imap_fetchbody($mbox,$i,'1')));
        $uuid=uniqid();
        $log="{$uuid}.log";
        foreach($body as $ln){
            $ln=trim($ln);
            switch(substr($ln,0,4)){
            case 'pge:':
                $url=str_replace('pge:','',trim($ln));
                $row=array('pge' => $url, 'to' => base64_encode($referer));
                $json['data'][]=$row;
                break;
            case 'pic:':
                $url=str_replace('pic:','',trim($ln));
                $row=array('pic' => $url, 'to' => base64_encode($referer), "log" => $log);
                $json['data'][]=$row;
                break;
            case 'res:':
                $url=str_replace('res:','',trim($ln));
                $row=array('res' => $url, 'to' => base64_encode($referer), "log" => $log);
                $json['data'][]=$row;
                break;
            }

        }
        if($str = imap_errors()){
            mail($referer,'Errors processing', htmlspecialchars(var_export($str, true)));
            $json['msg']=$str;
        }
        imap_delete($mbox, 1);
        imap_expunge($mbox);
    }
    imap_close($mbox);
    $json['success']=true;
}else{ 
    $json['success']=false;
    $json['msg']=var_export(imap_errors(),true);
}

echo json_encode($json);
?>