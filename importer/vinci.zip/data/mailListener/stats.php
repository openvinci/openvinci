<?php require('../../core.php'); 
if(!filter_input(INPUT_GET, 'id')){
    //session init, register and return id
    
    if (($handle = fopen("stats.csv", "a+")) !== FALSE) {
        $fields=array(
            'id' => session_id(),
            'start' => microtime(true),
            'end' =>''
        );
        fputcsv($handle, $fields);
        fclose($handle);
        echo $fields['id'];
    }

}else{
    //session exit, complete info
    $rows = array();
    if (($handle = fopen("stats.csv", "a+")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $rows[]=$data;
        }
        fclose($handle);
        foreach($rows as $i => $row){
            if($row[0]==$_REQUEST['id'])$rows[$i][2]=microtime(true);
        }
        $handle = fopen("stats.csv", "w+");
        foreach($rows as $i => $row){
            fputcsv($handle, $row);
        }
        fclose($handle);        
    }
}
?>

