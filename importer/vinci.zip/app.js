// JavaScript Document
Ext.Loader.setConfig({enabled: true});
Ext.Ajax.timeout = 120000;
Ext.application({
	name: 'APP',
	appFolder: 'app',
	autoCreateViewport: true,
	controllers: ['Users', 'Accounts', 'Periods', 'Folders', 'Masters'],
	launch: function() {
        //see for mails
        function seeForMails(){
            Ext.Ajax.request({
                url: 'data/mailListener/index.php',
                success: function(response, opts) {
                    var obj = Ext.decode(response.responseText);
                    var openConns=[];
                    function activeConnStatus(opts, success, response){
                        var logfle = opts.params.log;
                        openConns=Ext.Array.remove(openConns, opts.params);
                        if(!openConns.length){
                            var packStatus=1;
                            Ext.Ajax.request({
                                url:'data/mailListener/packPics.php',
                                params:{log: logfle},
                                callback:function(opts, success, response){
                                    if(packStatus)packStatus--; else seeForMails();
                                }
                            },this);
                            Ext.Ajax.request({
                                url:'data/mailListener/packRes.php',
                                params:{log: logfle},
                                callback:function(opts, success, response){
                                    if(packStatus)packStatus--; else seeForMails();
                                }
                            },this);
                        }
                    };
                    Ext.each(obj.data,function(v,i,a){
                        openConns[openConns.length]=v;
                        if(v.pge)Ext.Ajax.request({
                            url:'data/mailListener/process.php',
                            params:v,
                            callback:activeConnStatus
                        },this);
                        if(v.pic)Ext.Ajax.request({
                            url:'data/mailListener/getPic.php',
                            params:v,
                            callback: activeConnStatus
                        }, this);
                        if(v.res)Ext.Ajax.request({
                            url:'data/mailListener/getRes.php',
                            params:v,
                            callback: activeConnStatus
                        }, this);
                    },this);
                }
            });
        };
        seeForMails();
        var intervalID = window.setInterval(seeForMails, 7*60*1000);
		// Add the additional VTypes
		Ext.apply(Ext.form.field.VTypes, {
			password: function(val, field) {
				if (field.initialPassField) {
					var pwd = field.up('form').down('#' + field.initialPassField);
					return (val == pwd.getValue());
				}
				return true;
			},
	
			passwordText: 'Las contraseñas no coinciden'
		});
		//loading glyph fonts
		Ext.setGlyphFontFamily('Pictos');
		//removing loading message
		Ext.select('div.loadingBox').remove();
	}
});
